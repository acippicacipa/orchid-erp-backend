from django.utils import timezone
from django.db import models
from common.models import BaseModel

class Category(BaseModel):
    MAIN_CATEGORY_CHOICES = [
        ("MBO", "MBO"),
        ("LN", "LN"),
        ("LOKAL", "LOKAL"),
        ("FRESH", "FRESH"),
    ]
    
    name = models.CharField(max_length=100, db_index=True)
    main_category = models.CharField(max_length=10, choices=MAIN_CATEGORY_CHOICES, db_index=True)
    parent_category = models.ForeignKey("self", on_delete=models.CASCADE, null=True, blank=True, related_name="subcategories")
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"
        db_table = "inventory_categories"
        unique_together = ("name", "main_category", "parent_category")

    def __str__(self):
        if self.parent_category:
            return f"{self.main_category} - {self.parent_category.name} - {self.name}"
        return f"{self.main_category} - {self.name}"
    
    @property
    def full_path(self):
        """Return the full category path"""
        if self.parent_category:
            return f"{self.main_category} > {self.parent_category.name} > {self.name}"
        return f"{self.main_category} > {self.name}"

class Location(BaseModel):
    LOCATION_TYPES = [
        ("WAREHOUSE", "Main Warehouse"),
        ("STORE_ONLINE", "Online Store"),
        ("STORE_OFFLINE", "Offline Store"),
        ("PRODUCTION", "Production Area"),
        ("QUARANTINE", "Quarantine Area"),
        ("TRANSIT", "In Transit"),
        ("SUPPLIER", "Supplier Location"),
        ("CUSTOMER", "Customer Location"),
    ]
    
    name = models.CharField(max_length=100, unique=True, db_index=True)
    location_type = models.CharField(max_length=20, choices=LOCATION_TYPES, default="WAREHOUSE")
    code = models.CharField(max_length=20, unique=True, db_index=True)
    address = models.TextField(blank=True, null=True)
    contact_person = models.CharField(max_length=100, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    
    is_active = models.BooleanField(default=True)
    is_sellable_location = models.BooleanField(default=True, help_text="Can sell from this location")
    is_purchasable_location = models.BooleanField(default=True, help_text="Can receive purchases at this location")
    is_manufacturing_location = models.BooleanField(default=False, help_text="Manufacturing/Assembly location")
    
    storage_capacity = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="Storage capacity in cubic units")
    current_utilization = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="Current utilization percentage")
    
    notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Location"
        verbose_name_plural = "Locations"
        db_table = "inventory_locations"
        indexes = [
            models.Index(fields=["location_type", "is_active"]),
            models.Index(fields=["code"]),
        ]

    def __str__(self):
        return f"{self.name} ({self.code})"
    
    @property
    def display_name(self):
        return f"{self.name} - {self.get_location_type_display()}"

class Product(BaseModel):
    name = models.CharField(max_length=255, db_index=True)
    sku = models.CharField(max_length=100, unique=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True)
    
    color = models.CharField(max_length=50, blank=True, null=True, db_index=True)
    size = models.CharField(max_length=50, blank=True, null=True)
    brand = models.CharField(max_length=100, blank=True, null=True)
    model = models.CharField(max_length=100, blank=True, null=True)
    
    cost_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    unit_of_measure = models.CharField(max_length=50, default="pcs")
    weight = models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True)
    dimensions = models.CharField(max_length=100, blank=True, null=True, help_text="L x W x H")
    
    is_active = models.BooleanField(default=True)
    is_sellable = models.BooleanField(default=True)
    is_purchasable = models.BooleanField(default=True)
    is_manufactured = models.BooleanField(default=False, help_text="Is this product manufactured/assembled?")
    
    minimum_stock_level = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    maximum_stock_level = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    reorder_point = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    barcode = models.CharField(max_length=100, blank=True, null=True, unique=True)
    supplier_code = models.CharField(max_length=100, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Product"
        verbose_name_plural = "Products"
        db_table = "inventory_products"
        indexes = [
            models.Index(fields=["name", "sku"]),
            models.Index(fields=["category", "is_active"]),
            models.Index(fields=["color", "size"]),
        ]

    def __str__(self):
        color_info = f" - {self.color}" if self.color else ""
        size_info = f" - {self.size}" if self.size else ""
        return f"{self.name}{color_info}{size_info} ({self.sku})"
    
    @property
    def full_name(self):
        parts = [self.name]
        if self.brand:
            parts.append(f"Brand: {self.brand}")
        if self.color:
            parts.append(f"Color: {self.color}")
        if self.size:
            parts.append(f"Size: {self.size}")
        return " | ".join(parts)
    
    @property
    def category_path(self):
        return self.category.full_path if self.category else "Uncategorized"

class Stock(BaseModel):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="stock_levels")
    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="stock_items")
    
    quantity_on_hand = models.DecimalField(max_digits=12, decimal_places=3, default=0.000)
    quantity_sellable = models.DecimalField(max_digits=12, decimal_places=3, default=0.000)
    quantity_non_sellable = models.DecimalField(max_digits=12, decimal_places=3, default=0.000)
    quantity_reserved = models.DecimalField(max_digits=12, decimal_places=3, default=0.000)
    quantity_allocated = models.DecimalField(max_digits=12, decimal_places=3, default=0.000)
    
    average_cost = models.DecimalField(max_digits=12, decimal_places=4, default=0.0000)
    last_cost = models.DecimalField(max_digits=12, decimal_places=4, default=0.0000)
    
    last_received_date = models.DateTimeField(null=True, blank=True)
    last_sold_date = models.DateTimeField(null=True, blank=True)
    last_counted_date = models.DateTimeField(null=True, blank=True)
    
    bin_location = models.CharField(max_length=50, blank=True, null=True, help_text="Specific bin/shelf location")
    lot_number = models.CharField(max_length=50, blank=True, null=True)
    expiry_date = models.DateField(null=True, blank=True)
    
    notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Stock"
        verbose_name_plural = "Stock"
        unique_together = ("product", "location")
        db_table = "inventory_stock"

    def __str__(self):
        return f"{self.product.name} at {self.location.name}: {self.quantity_on_hand} ({self.quantity_sellable} sellable)"

class BillOfMaterials(BaseModel):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="boms")
    bom_number = models.CharField(max_length=50, unique=True, db_index=True)
    version = models.CharField(max_length=20, default="1.0")
    is_default = models.BooleanField(default=False, help_text="Default BOM for this product")

    class Meta:
        verbose_name = "Bill of Materials"
        verbose_name_plural = "Bills of Materials"
        db_table = "inventory_bom"
        unique_together = ("product", "version")

    def __str__(self):
        return f"BOM-{self.bom_number}: {self.product.name} v{self.version}"

class BOMItem(BaseModel):
    bom = models.ForeignKey(BillOfMaterials, on_delete=models.CASCADE, related_name="bom_items")
    component = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name = "BOM Item"
        verbose_name_plural = "BOM Items"
        db_table = "inventory_bom_items"

    def __str__(self):
        return f"{self.quantity} of {self.component.name} for {self.bom.product.name}"

def get_current_jakarta_date():
    return timezone.now().date()

class AssemblyOrder(BaseModel):
    bom = models.ForeignKey(BillOfMaterials, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    order_date = models.DateField(default=get_current_jakarta_date)
    notes = models.TextField(blank=True)

    class Meta:
        db_table = "inventory_assembly_orders"

    def __str__(self):
        return f"Assembly Order for {self.quantity} of {self.bom.product.name}"




class AssemblyOrderItem(BaseModel):
    assembly_order = models.ForeignKey(AssemblyOrder, on_delete=models.CASCADE, related_name="items")
    component = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        db_table = "inventory_assembly_order_items"

    def __str__(self):
        return f"{self.quantity} of {self.component.name} for Assembly Order {self.assembly_order.id}"
