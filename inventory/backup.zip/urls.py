from rest_framework.routers import DefaultRouter
from .views import AssemblyOrderViewSet, BillOfMaterialsViewSet, CategoryViewSet, LocationViewSet, ProductViewSet, StockViewSet

router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'locations', LocationViewSet)
router.register(r'products', ProductViewSet)
router.register(r'stock', StockViewSet)
router.register(r'boms', BillOfMaterialsViewSet)
router.register(r'assembly-orders', AssemblyOrderViewSet)

urlpatterns = router.urls

