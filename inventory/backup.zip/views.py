from rest_framework import viewsets
from rest_framework.permissions import AllowAny  # <-- 1. Impor AllowAny
from accounts.permissions import IsAdminOrWarehouse
from .models import AssemblyOrder, BillOfMaterials, Category, Location, Product, Stock
from .serializers import AssemblyOrderSerializer, BillOfMaterialsSerializer, CategorySerializer, LocationSerializer, ProductSerializer, StockSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    permission_classes = [AllowAny]
    #permission_classes = [IsAdminOrWarehouse]
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class LocationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrWarehouse]
    queryset = Location.objects.all()
    serializer_class = LocationSerializer

class ProductViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrWarehouse]
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class StockViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrWarehouse]
    queryset = Stock.objects.all()
    serializer_class = StockSerializer

class BillOfMaterialsViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrWarehouse]
    queryset = BillOfMaterials.objects.all()
    serializer_class = BillOfMaterialsSerializer

class AssemblyOrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrWarehouse]
    queryset = AssemblyOrder.objects.all()
    serializer_class = AssemblyOrderSerializer

