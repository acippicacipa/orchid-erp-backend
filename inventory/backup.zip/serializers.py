from rest_framework import serializers
from .models import AssemblyOrder, AssemblyOrderItem, BillOfMaterials, BOMItem, Category, Location, Product, Stock

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = Product
        fields = '__all__'

class StockSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    location_name = serializers.CharField(source='location.name', read_only=True)

    class Meta:
        model = Stock
        fields = '__all__'




class BillOfMaterialsItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = BOMItem
        fields = '__all__'

class BillOfMaterialsSerializer(serializers.ModelSerializer):
    items = BillOfMaterialsItemSerializer(many=True, read_only=True)

    class Meta:
        model = BillOfMaterials
        fields = '__all__'

class AssemblyOrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssemblyOrderItem
        fields = '__all__'

class AssemblyOrderSerializer(serializers.ModelSerializer):
    items = AssemblyOrderItemSerializer(many=True, read_only=True)

    class Meta:
        model = AssemblyOrder
        fields = '__all__'

